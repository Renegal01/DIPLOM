__all__ = ("Enum")
